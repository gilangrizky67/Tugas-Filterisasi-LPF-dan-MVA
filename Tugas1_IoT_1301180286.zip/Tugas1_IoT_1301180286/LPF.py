import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import butter,filtfilt


data = pd.read_csv('4.csv')
data.rename(columns = {'0':'Index'}, inplace = True)
data.rename(columns = {'2045':'xAxis'}, inplace = True)
data.rename(columns = {'2326':'yAxis'}, inplace = True)
data.rename(columns = {'1833':'zAxis'}, inplace = True)

def butter_lowpass_filter(data, cutoff, fs, order):
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    y = filtfilt(b, a, data)
    return y


ygdipake = data['yAxis']
fs = 52
nyq = 0.5 * fs
order = 2

cutoff =  1.5
hasil = butter_lowpass_filter(ygdipake, cutoff, fs, order)

plt.plot(data['Index'], data['yAxis'])
plt.plot(data['Index'], hasil)
plt.show()
