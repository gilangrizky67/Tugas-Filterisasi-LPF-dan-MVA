import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


data = pd.read_csv('4.csv')
data.rename(columns = {'0':'Index'}, inplace = True)
data.rename(columns = {'2045':'xAxis'}, inplace = True)
data.rename(columns = {'2326':'yAxis'}, inplace = True)
data.rename(columns = {'1833':'zAxis'}, inplace = True)
dataMVA = data

def moving_average(x, w):
    y = np.convolve(x, np.ones(w), 'valid') / w
    return y



hasil = moving_average(dataMVA['yAxis'],25)

x1 = np.linspace(0, 1, len(data['yAxis']))
x2 = np.linspace(0, 1, len(hasil))
plt.plot(x1, data['yAxis'])
plt.plot(x2, hasil)
plt.show()